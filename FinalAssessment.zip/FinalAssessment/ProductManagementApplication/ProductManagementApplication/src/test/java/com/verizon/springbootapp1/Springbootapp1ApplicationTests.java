package com.verizon.springbootapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
