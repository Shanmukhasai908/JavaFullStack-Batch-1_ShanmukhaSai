package com.verizon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import com.verizon.service.ProductService;
@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	@GetMapping("/product")
	public List<Product> getAllProducts() {  
		return productService.getProducts();
				
	}
	@GetMapping("/product/{pid}")
	public Product getProduct(@PathVariable("pid")Integer pid) { 
		return productService.getProduct(pid);
	}
	@GetMapping("/product/{low}/{high}")
	public List<Product> getProductBetweenPriceRange(@PathVariable("low")Integer low,@PathVariable("high")Integer high) throws ProductNotFoundException{  
		List<Product> productList= productService.getProductsBetweenLowHigh(low, high);  
		return productList;
	}
  @PostMapping("/product") 
	  public String  addProductDetails(@RequestBody	  Product product) { 
	  productService.addProduct(product);  
	  return  "Added";
	  }
	
	@PutMapping("/product/{pid}") 
	public Product updateProductDetails(@PathVariable("pid") Integer pid,@RequestBody Product product)  throws ProductNotFoundException {
		return productService.updateProduct(pid, product);
	}
	
	@DeleteMapping("/product/{pid}") 
	public String deleteProductDetails(@PathVariable("pid") Integer pid)  throws ProductNotFoundException{
		productService.deleteProduct(pid);
		return ("Deleted"); 
	}
	
}
