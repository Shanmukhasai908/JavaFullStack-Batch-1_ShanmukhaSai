package com.verizon.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.ProductDao;
import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import jakarta.transaction.Transactional;
@Service
@Transactional
public class ProductService {
	@Autowired
	ProductDao productDao;
	public String addProduct(Product product) {
		productDao.save(product);
		return "Added";
	}
	public   List<Product> getProducts() {
		
		List<Product> productList= productDao.findAll();  //call dao method
		return productList;
	}
	
	public Product getProduct(Integer id) throws ProductNotFoundException {
		Product product1=productDao.findById(id).orElseThrow(() -> new ProductNotFoundException("Product not Found with id: " + id));
		return product1;
	}
	
	public List<Product> getProductsBetweenLowHigh(Integer low,Integer high) throws ProductNotFoundException {
		
		List<Product> productList= productDao.findAllProductBetweenPrice(low, high);// call custom method  
		return productList;
	}
	public Product updateProduct(Integer pid,Product product)  throws ProductNotFoundException {
		Product product1=productDao.findById(pid).orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + pid));
		product1.setPrice(product.getPrice());
		return productDao.save(product1);
	}
	public void deleteProduct(Integer pid)  throws ProductNotFoundException {
		Product product1=productDao.findById(pid).orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + pid));
		productDao.delete(product1);
		}
	}
